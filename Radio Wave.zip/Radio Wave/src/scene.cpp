#include "scene.hpp"

Scene::Scene(){
}

Scene::~Scene(){

}
